/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab_05;

/**
 *
 * @author unifgaoliveira
 */
public class NavioMercante extends Navio{
    protected float capacidadeCarga;
    protected float carga;

    public NavioMercante(float capacidadeCarga, float carga, 
            int numTripulantes, String nome) {
        super(numTripulantes,nome);
        this.capacidadeCarga = capacidadeCarga;
        this.carga = carga;
    }
    public void carregamento(){
        double volume = carga/capacidadeCarga;
        System.out.println("Nome do navio: "+ nome);
        System.out.println("Valor de número de tripulantes: " + numTripulantes);
        System.out.println("Volume do navio ocupado: " + volume);
    }
    
}
