/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab_05;

/**
 *
 * @author unifgaoliveira
 */
public class Navio {
    protected int numTripulantes;
    protected String nome;

    public Navio(int numTripulantes, String nome) {
        this.numTripulantes = numTripulantes;
        this.nome = nome;
    }
    
    public void exibirInfoGeral(){
        System.out.println("Nome do navio: "+nome);
        System.out.println("Número de tripulantes: "+numTripulantes);
        
    }
    
}
