/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab_05;

/**
 *
 * @author unifgaoliveira
 */
public class Cruzador extends NavioDeGuerra{
    protected int numCanhoes;

    public Cruzador(int numCanhoes, float blindagem, float ataque, 
            int numTripulantes, String nome) {
        super(blindagem, ataque, numTripulantes, nome);
        this.numCanhoes = numCanhoes;
    }
    
    public void poderDeFogo(){
        double fogo_C = ataque*Math.sqrt(numCanhoes);
        System.out.println("Poder de fogo do Cruzador: " + fogo_C);
    }
    
}
