/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab_05;

/**
 *
 * @author unifgaoliveira
 */
public class PortaAvioes extends NavioDeGuerra{
    protected int numAvioes;

    public PortaAvioes(int numAvioes, float blindagem, float ataque, 
            int numTripulantes, String nome) {
        super(blindagem, ataque, numTripulantes, nome);
        this.numAvioes = numAvioes;    
    }
    
    public void poderDeFogo(){
        double fogo_A = ataque*(numAvioes * numAvioes);
        System.out.println("Poder de fogo do Avião: " + fogo_A);
    }
}
