/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab_05;

/**
 *
 * @author unifgaoliveira
 */
public class NavioDeGuerra extends Navio{
    protected float blindagem;
    protected float ataque;

    public NavioDeGuerra(float blindagem, float ataque, 
            int numTripulantes, String nome) {
        super(numTripulantes,nome);
        this.blindagem = blindagem;
        this.ataque = ataque;
    }
    public void poderDeFogo(){
        System.out.println("Valor do Ataque: " + ataque);        
    }
    
    public void exibirArmas(){
        System.out.println("Nome do Navio: "+ nome);
        System.out.println("Valor de blindagem: " + blindagem);
        System.out.println("Valor de número de tripulantes: " + numTripulantes);
        poderDeFogo();
    }
    
}
