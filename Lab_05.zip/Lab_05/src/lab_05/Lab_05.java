/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab_05;
import java.util.Scanner;
import java.util.ArrayList;

public class Lab_05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Navio naviozin_1 = new Navio(7,"Going Merry");
        Navio naviozin_2 = new Navio(9, "Thousand Sunny");
        NavioDeGuerra navio_g1 = new NavioDeGuerra(15,35,20,"Shepard");
        NavioDeGuerra navio_g2 = new NavioDeGuerra(10,50,40,"Liones");
        NavioMercante navio_m1 = new NavioMercante(23,78,68,"Brodway");
        NavioMercante navio_m2 = new NavioMercante(12,54,39,"Tomato");
        Cruzador cruz_1 = new Cruzador(15,70,105,40,"Tankasso");
        Cruzador cruz_2 = new Cruzador(34,3,150,43,"Squish");
        PortaAvioes pt_1 = new PortaAvioes(12,15,30,45,"HelloWorld");
        PortaAvioes pt_2 = new PortaAvioes(67,43,32,14,"Dell");
        
        System.out.println("---NAVIO---");
        naviozin_1.exibirInfoGeral();
        naviozin_2.exibirInfoGeral();
        
        System.out.println("---NAVIO DE GUERRA---");
        navio_g1.exibirArmas();
        navio_g1.poderDeFogo();
        
        navio_g2.exibirArmas();
        navio_g2.poderDeFogo();
        
        System.out.println("---NAVIO MERCANTE---");
        navio_m1.carregamento();
        navio_m2.carregamento();
        
        System.out.println("---CRUZADOR---");
        cruz_1.poderDeFogo();
        cruz_2.poderDeFogo();
        
        System.out.println("---PORTA AVIÕES---");
        pt_1.poderDeFogo();
        pt_2.poderDeFogo();
        
    }
    
}
