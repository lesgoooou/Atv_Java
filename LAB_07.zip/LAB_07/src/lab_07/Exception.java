
package lab_07;

public class Exception extends RuntimeException{
    public Exception(String message){
        super(message);
    }
}