
package lab_07;
import java.util.Scanner;

public class Main {

    public static void excecao(String cpf){
        if (cpf.contains(".")){
            throw new Exception("não inserira . ou -");
        } else if(cpf.contains("-")){
            throw new Exception("não inserira . ou -");
        }
    }
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Digite seu nome: ");
        String nome = input.nextLine();
        System.out.println("Agora digite seu sobrenome: ");
        String sobrenome = input.nextLine();
        System.out.println("Sua Idade: ");
        int idade = input.nextInt();
        input.nextLine();
        
        while(true){
            try{
                System.out.println("Digite seu CPF: ");
                String cpf = input.nextLine();
                excecao(cpf);
                Pessoa p1 = new Pessoa(nome, sobrenome, idade, cpf);
                break;
            }catch(Exception e){
                System.out.println("Deu o erro "+ e.getMessage());
            }
        }

    }
    
}
