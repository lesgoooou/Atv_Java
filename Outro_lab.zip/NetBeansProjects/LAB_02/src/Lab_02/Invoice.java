
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab_02;

/**
 *
 * @author unifgaoliveira
 */
public class Invoice {
    private String identificador;
    private String desc;
    private int qtd;
    private double preco;
    
    public String getIdentificador(){
        return identificador;
    }
    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }
    
    
    public String getDesc(){
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }
    
    
    public int getQtd(){
        return qtd;
    }   
    public void setQtd(int qtd) {
        this.qtd = qtd;
    }
    
    
    public double getPreco(){
        return preco;
    }    
    public void setPreco(double preco) {
        this.preco = preco;
    }
    
    public double getInvoiceAmount() {
        if (qtd<0) {
            qtd = 0;
        }
        else if (preco<0) {
            preco = 0;
        }
        double fatura = qtd*preco;
        return fatura;
    }
}