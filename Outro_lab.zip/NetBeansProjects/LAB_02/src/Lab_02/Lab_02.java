/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Lab_02;
import java.util.Scanner;
/**
 *
 * @author unifgaoliveira
 */
public class Lab_02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Invoice i1 = new Invoice();
        Invoice i2 = new Invoice();

        /* Invoice 1*/
        System.out.println("Por favor insira os dados do Item 1");
        System.out.println("Identificador: ");
        i1.setIdentificador(input.next());
        System.out.println("Descrição: ");
        i1.setDesc(input.next());
        System.out.println("Quantidade: ");
        i1.setQtd(input.nextInt());
        System.out.println("Preço: ");
        i1.setPreco(input.nextDouble());
        System.out.println("");
        
        /* Invoice 2*/        
        System.out.println("Por favor insira os dados do Item 2");
        System.out.println("Identificador: ");
        i2.setIdentificador(input.next());
        System.out.println("Descrição: "); 
        i2.setDesc(input.next());
        System.out.println("Quantidade: ");
        i2.setQtd(input.nextInt());
        System.out.println("Preço: ");
        i2.setPreco(input.nextDouble());
        
        System.out.println("Segue a fatura dos Itens vendidos");
        System.out.println("");
        System.out.println("FATURA 1");
        System.out.println("Identificador: " + i1.getIdentificador());
        System.out.println("Descrição: " + i1.getDesc());
        System.out.println("Quantidade: " + i1.getQtd());
        System.out.println("Preço: " + i1.getPreco());
        System.out.println("Fatura: " + i1.getInvoiceAmount());
        System.out.println("");
        System.out.println("FATURA 2");
        System.out.println("Identificador: " + i2.getIdentificador());
        System.out.println("Descrição: " + i2.getDesc());
        System.out.println("Quantidade: " + i2.getQtd());
        System.out.println("Preço: " + i2.getPreco());
        System.out.println("Fatura: " + i2.getInvoiceAmount());
    }
    
}