/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labo_3;
import java.util.Scanner;
/**
 *
 * @author unifgaoliveira
 */
public class LABO_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Como você quer informar a data? ");
        System.out.println("1. mm/dd/yyyy");
        System.out.println("2. Fevereiro 27, 2025");
        System.out.println("3. Ddd/yyyy");
        System.out.println("Escolha: ");
       
        int esc = input.nextInt();
        
        if (esc == 1) {
           System.out.println("Dia: ");
           int dia = input.nextInt();

           System.out.println("Mês: ");
           int mes = input.nextInt();

           System.out.println("Ano: ");
           int ano = input.nextInt();
           
           Data data = new Data(mes,dia,ano);
        } else if (esc == 2) {
           System.out.println("Dia: ");
           int dia = input.nextInt();

           input.nextLine();
           System.out.println("Mês: ");
           String mes_str = input.nextLine();

           System.out.println("Ano: ");
           int ano = input.nextInt();

           Data data = new Data(mes_str, dia, ano);
        } else if (esc == 3) {
           System.out.println("Dia: ");
           int dia_j = input.nextInt();

           System.out.println("Ano: ");
           int ano = input.nextInt();

           Data data = new Data(dia_j, ano);
        }
        
        System.out.println("Como você quer exibir a data? ");
        System.out.println("1. mm/dd/yyyy");
        System.out.println("2. Fevereiro 27, 2025");
        System.out.println("3. Ddd/yyyy");
        System.out.println("Escolha: ");
        int esc_2 = input.nextInt();
        
        if (esc_2 == 1) {
            data.print();
        } else if (esc_2 == 2) {
            if (esc == 1 || esc == 2) {
                data.converte_mes(data.getMes());

                System.out.printf("%s %d, %d\n", data.getMes_str(), data.getDia(), data.getAno());
            }
        } else if (esc-2 == 3) {
            
        }
        
        
        
        
    }
    
}
