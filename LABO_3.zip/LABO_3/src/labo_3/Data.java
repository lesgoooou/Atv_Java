/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labo_3;
import java.util.Scanner;

public class Data {
    private int dia;
    private int dia_j;
    private int mes;
    private int ano;
    private String mes_str;
    
    public Data(int dia, int mes, int ano) {
        this.dia = dia;
        this.ano = ano;
        this.mes = mes;
    }
    
    public Data(String mes_str, int dia, int ano) {
        this.dia = dia;
        this.ano = ano;
        switch (mes_str) {
            case "Janeiro":
                this.mes = 1;
                break;
            case "Fevereiro":
                this.mes = 2;
                break;
            case "Março":
                this.mes = 3;
                break;
            case "Abril":
                this.mes = 4;
                break;
            case "Maio":
                this.mes = 5;
                break;
            case "Junho":
                this.mes = 6;
                break;
            case "Julho":
                this.mes = 7;
                break;
            case "Agosto":
                this.mes = 8;
                break;
            case "Setembro":
                this.mes = 9;
                break;
            case "Outubro":
                this.mes = 10;
                break;
            case "Novembro":
                this.mes = 11;
                break;
            case "Dezembro":
                this.mes = 12;
                break;
            default:
                this.mes = 1;
                break;
        }
    }
    
    public Data(int dia_j, int ano) {
       this.ano = ano;
       if (dia_j>=1 && dia_j<=31) {
           mes = 1;
           dia = dia_j;
       } else if (dia_j>= 32 && dia_j<= 58) {
           mes = 2;
           dia = dia_j - 31;
       } else if (dia_j>= 59 && dia_j<= 90) {
           mes = 3;
           dia = dia_j - 58;
       } else if (dia_j>= 91 && dia_j<= 120) {
           mes = 4;
           dia = dia_j - 90;
       } else if (dia_j>= 121 && dia_j<= 151) {
           mes = 5;
           dia = dia_j - 120;
       } else if (dia_j>= 152 && dia_j<= 181) {
           mes = 6;
           dia = dia_j - 151;
       } else if (dia_j>= 182 && dia_j<= 212) {
           mes = 7;
           dia = dia_j - 181;
       } else if (dia_j>= 213 && dia_j<= 243) {
           mes = 8;
           dia = dia_j - 212;
       } else if (dia_j>= 244 && dia_j<= 273) {
           mes = 9;
           dia = dia_j - 243;
       } else if (dia_j>= 274 && dia_j<= 304) {
           mes = 10;
           dia = dia_j - 273;
       } else if (dia_j>= 305 && dia_j<= 334) {
           mes = 11;
           dia = dia_j - 304;
       } else if (dia_j>= 335 && dia_j<= 365) {
           mes = 12;
           dia = dia_j - 334;
       } else {
           this.dia = 1;
           this.mes = 1;
       }
       
    }
    
    public int getDia() {
        return dia;
    }
    public int getDia_j() {
        return dia;
    }   
    public int getMes() {
        return mes;
    }
    public int getAno() {
        return ano;
    }
    
    public void setDia(int dia) {
        this.dia = dia;
    }
    public void setDia_j(int dia_j) {
        this.dia_j = dia_j;
    }
    public void setMes(int mes) {
        this.mes = mes;
    }
    public void setMes_str(String mes_str) {
        this.mes_str = mes_str;
    }
    public void setAno(int ano) {
        this.ano = ano;
    }
    
    private int diaValido (int dia) {
        if(dia>0 && dia<32) {
            return dia;
        }
        else {
            return 1;
        }
    }
    
    public void converte_mes(int mes) {
        switch (mes) {
            case 1:
                this.mes_str = "Janeiro";
                break;
            case 2:
                this.mes_str = "Fevereiro";
                break;
            case 3:
                this.mes_str = "Março";
                break;
            case 4:
                this.mes_str = "Abril";
                break;
            case 5:
                this.mes_str = "Maio";
                break;
            case 6:
                this.mes_str = "Junho";
                break;
            case 7:
                this.mes_str = "Julho";
                break;
            case 8:
                this.mes_str = "Agosto";
                break;
            case 9:
                this.mes_str = "Setembro";
                break;
            case 10:
                this.mes_str = "Outubro";
                break;
            case 11:
                this.mes_str = "Dezembro";
                break;
            case 12:
                this.mes_str = "Novembro";
                break;
            default:
                this.mes = 1;
                break;
    
        }
    }
    public void print() {
        System.out.printf("%d/%d/%d\n", dia, mes, ano);
    }
   
}
    

