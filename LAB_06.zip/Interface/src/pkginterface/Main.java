package pkginterface;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Agente> agente = new ArrayList<>();
        Random random = new Random();
   
        System.out.println("Neo, a Matrix é um grande sistema orientado a objetos, em que as pessoas são objetos de\n" +
        "classes que herdam da classe abstrata Agente");
   
        System.out.println("Bem vindo o que você gostaria de fazer"
                + "(Escolha um número de 1 a 4): ");       
            
        while (true){
            System.out.println("----- MENU -----");
            System.out.println("1. Inserir agente");
            System.out.println("2. Consultar agentes");
            System.out.println("3. Remover agente");
            System.out.println("4. Terminar Programa");
            int esc = input.nextInt();
            input.nextLine();
            
            if(esc == 1) {
                System.out.println("----- REGISTRO -----");
                int numAleatorio = random.nextInt(20)+1;
                boolean modoAgente = (numAleatorio % 5 == 0);
                System.out.println("Insira o nome: ");
                String nome = input.nextLine();
                System.out.println("Insira a profissão: ");
                String profissao = input.nextLine();
                
                if(profissao.equals("Professor")){
                    System.out.println("Escola: ");
                    String escola = input.nextLine();
                    agente.add(new Professor(nome,modoAgente,profissao, escola));
                } else if(profissao.equals("Advogado")){
                    System.out.println("OAB: ");
                    String OAB = input.nextLine();
                    agente.add(new Advogado(nome,modoAgente,profissao, OAB));
                } else if(profissao.equals("Empresario")) {
                    System.out.println("Empresa: ");
                    String empresa = input.nextLine();
                    agente.add(new Empresario(nome,modoAgente,profissao, empresa));
                }
            } else if (esc == 2){
                    System.out.println("----- LISTA DE AGENTES -----");
                    
                    if (agente.isEmpty()) {
                        System.out.println("Não há agentes cadastrados.");
                    } else {
                        for (int i = 0; i < agente.size(); i++) {
                            System.out.println("Agente " + (i+1) + ":");
                            agente.get(i).apresentacao(); 
                            System.out.println("--------------------");
                        }
                    }
            } else if (esc == 3){
                if (agente.isEmpty()) {
                    System.out.println("Não há agentes cadastrados para remover.");
                } else {
                    System.out.println("----- LISTA DE AGENTES -----");
                    for (int i = 0; i < agente.size(); i++) {
                        System.out.println((i+1) + ". " + agente.get(i).nome);
                    }
                    
                    System.out.println("\nDigite o número do agente que deseja remover: ");
                    int posicao = input.nextInt();
                    input.nextLine();
                    
                    if (posicao >= 1 && posicao <= agente.size()) {
                        agente.remove(posicao - 1);
                        System.out.println("Agente removido com sucesso!");
                    } else {
                        System.out.println("Posição inválida!");
                    }
                }
            } else if (esc == 4){
                System.out.println("Programa encerrado.");
                break;
            }
        }
    }
    
}
