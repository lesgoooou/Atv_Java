package pkginterface;

public class Professor extends Agente{
    private String escola;

    public Professor(String nome, boolean modo_agente, 
            String profissao, String escola) {
        super(nome, modo_agente, profissao);
        this.escola = escola;
    }
    
    public void apresentacao() {
        if (modo_agente == true) {
            System.out.println("AGENTE SMITH!");
        } else {
            System.out.println("Nome: " + nome);
            System.out.println("Profissão: " + profissao);
            System.out.println("Escola: " + escola);
        }
    }
}
