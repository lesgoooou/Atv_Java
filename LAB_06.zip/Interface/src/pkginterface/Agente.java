package pkginterface;


public abstract class Agente {
    protected String nome;
    protected boolean modo_agente;
    protected String profissao;
    
    public Agente(String nome, boolean modo_agente, String profissao){
        this.nome = nome;
        this.modo_agente = modo_agente;
        this.profissao = profissao;
    }
    
    public abstract void apresentacao();
    
    public boolean modo_agente_on(){
        return this.modo_agente = true;
    };
    
}
