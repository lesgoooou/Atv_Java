package pkginterface;

public class Advogado extends Agente{
    protected String OAB;

    public Advogado(String nome, boolean modo_agente, String profissao, 
            String OAB) {
        super(nome, modo_agente, profissao);
        this.OAB = OAB;
    }
    
    public void apresentacao() {
        if (modo_agente == true) {
            System.out.println("AGENTE SMITH!");
        } else {
            System.out.println("Nome: " + nome);
            System.out.println("Profissão: " + profissao);
            System.out.println("OAB: " + OAB);
        }
    }
}
