package pkginterface;


public class Empresario extends Agente{
    protected String empresa;

    public Empresario(String nome, boolean modo_agente, String profissao, 
            String empresa) {
        super(nome, modo_agente, profissao);
        this.empresa = empresa;
    }
    
    public void apresentacao() {
        if (modo_agente == true) {
            System.out.println("AGENTE SMITH!");
        } else {
            System.out.println("Nome: " + nome);
            System.out.println("Profissão: " + profissao);
            System.out.println("Empresa: " + empresa);
        }
    }
}
