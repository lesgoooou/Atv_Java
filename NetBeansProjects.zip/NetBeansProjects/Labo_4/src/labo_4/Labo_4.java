/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labo_4;
import java.util.Scanner;
/**
 *
 * @author unifgaoliveira
 */
public class Labo_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Digite as notas: ");
        double contador = 0;
        int total = 0;
        for (int i = 1; i <= 80; i+= 1) {
            double nota = input.nextDouble();
            contador += nota;
            if (nota >= 6) {
                total += 1;
            }
        };
        double media = contador/4;
        System.out.println("Qtd alunos que passaram: " + total);
        System.out.println("Media alunos: " + media);
        
        // TODO code application logic here
    }
    
}
