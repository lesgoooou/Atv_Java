/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labo;

/**
 *
 * @author unifgaoliveira
 */
public class Labo_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Os números pares de 0 a 100: ");
        for (int i = 0; i <= 100; i+=2){
            System.out.println(i);  
        }
        // TODO code application logic here
    }
    
}
