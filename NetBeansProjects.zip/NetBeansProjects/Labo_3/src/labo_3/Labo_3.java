/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labo_3;
import java.util.Scanner;
/**
 *
 * @author unifgaoliveira
 */
public class Labo_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        while (true){
            System.out.println("Escolha um número inteiro o positivo: ");
            int num = input.nextInt();
            if (num < 0) {
                break;
            }
            else {
                double S = 0;
                for (int i = 1; i<= num; i+=1) {
                    S += 1.0/i;
                }
                System.out.println(S);                   
            }
        }
        // TODO code application logic here
    }
    
}
