/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labo_5;
import java.util.Scanner;
/**
 *
 * @author unifgaoliveira
 */
public class Labo_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Quantas pessoas têm no grupo: ");
        int qtd = input.nextInt();
        
        double total_idade = 0;
                
        System.out.println("Informe sua idade: ");
        for (int i = 0; i<= qtd; i++) { 
        int idade = input.nextInt();
        total_idade += idade;
        }
        System.out.println("Informe seu sexo (M/F): ");
        for (int i = 0; i<= qtd; i++) { 
        char sexo = input.next().charAt(0);
        }
        System.out.println("Informe seu salario: ");        
        for (int i = 0; i<= qtd; i++) { 
        double salario = input.nextInt();
        }
        System.out.println("Média Idades: ");
        System.out.println(total_idade/qtd);
        
        
        // TODO code application logic here
    }
    
}
