/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab_04;

/**
 *
 * @author unifgaoliveira
 */
public class Pessoa {
    private static int contador = 1;
    private String nome;
    private String tel;
    private int id;

    Pessoa (String nome, String tel) {
        this.id = contador++;
        this.nome = nome;
        this.tel = tel;
    }

    public String getNome(){
        return nome;
    }
    public String getTel(){
        return tel;
    }
    public int getId(){
        return id;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    public void setTel(String tel){
        this.tel = tel;
    }
}
