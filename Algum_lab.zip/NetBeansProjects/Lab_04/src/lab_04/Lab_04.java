package lab_04;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author unifgaoliveira
 */
public class Lab_04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Pessoa> pessoa = new ArrayList<>();
        
        while (true) {
            System.out.println("Entre com uma das seguintes opções: ");
            System.out.println("n [nova entrada]");
            System.out.println("d [apaga registro da agenda]");
            System.out.println("p [imprime toda a agenda]");
            System.out.println("q [sai do programa]");
            char esc = input.next().charAt(0);
            input.nextLine();

            if (esc == 'n') {
                System.out.println('Insira o nome: ');
                String nome = input.nextLine();

                System.out.println('Insira o telefone: ');
                String telefone = input.nextLine();

                usuario.add(new Pessoa(nome,telefone));
                System.out.println("Sucesso!")
                break;
            } else if (esc == 'd') {
                System.out.println("Você gostaria de inserir o Nome(n) ou o Telefone(t): ");
                char opc = input.next().charAt(0);
                input.nextLine();

                if(opc == 'n'){
                    System.out.println("Insira o nome da pessoa que será excluída: ");
                    String nome = input.nextLine();

                    boolean removido = usuario.removeIf(p -> p.getNome().equals(nome));
                    if (!removido){
                        System.out.println("Pessoa não encontrada!")
                    } else {
                        System.out.println("Contato Removido!")
                    }
                }
                if(opc == 't'){
                    System.out.println("Insira o telefone da pessoa que será excluída: ");
                    String telefone = input.nextLine();

                    boolean removido = usuario.removeIf(p -> p.getTel().equals(telefone));
                    if (!removido){
                        System.out.println("Telefone não encontrada!")
                    } else {
                        System.out.println("Contato Removido!")
                    }
                }
            } else if (esc == 'p') {
                if (usuario.isEmpty()) {
                    System.out.println("A agenda está vazia.");
                } else {
                    System.out.println("\nLista de contatos:");
                    for (Pessoa p : pessoa) {
                            System.out.println("Nome: "+ getNome() + "| Telefone: " + getTel() + "| ID: " + getId());
                        }
                    }
                }
            } else if (esc == 'q') {
                System.out.println("Obrigado!");
                System.exit(0);
            } else {
                System.out.println("Escolha uma opção disponivel!");
            }

        }

    }
    
}
